"""Integration tests for SEO Analyzer API.

This package contains integration tests that verify the interaction between
different components of the SEO Analyzer system.
"""