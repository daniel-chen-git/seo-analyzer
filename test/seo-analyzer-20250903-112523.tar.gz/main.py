def main():
    print("Hello from seo-analyzer!")


if __name__ == "__main__":
    main()
